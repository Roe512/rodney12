// Select all videos in the portfolio section
const videos = document.querySelectorAll("#portfolio video");

// Create an Intersection Observer
const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.play(); // Play video when in view
        } else {
            entry.target.pause(); // Pause video when out of view
            entry.target.currentTime = 0; // Reset to start
        }
    });
}, { threshold: 0.5 }); // Video must be at least 50% visible

// Observe each video
videos.forEach(video => observer.observe(video));
